price=None
if float(price)>300.00:
    print(price)
print(price)